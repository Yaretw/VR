var APP_DATA = {
  "scenes": [
    {
      "id": "0-home",
      "name": "HOME",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -0.16356717126105558,
        "pitch": -0.42423948684988666,
        "fov": 1.3926760049349705
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "HOME",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
